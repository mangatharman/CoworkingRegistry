var sqlite3 = require('sqlite3').verbose();
let db = new sqlite3.Database('./listingsData.db', sqlite3.OPEN_READWRITE,(err) => {
    if(err){
        return console.error(err.message);
    }
    console.log("Connected to database.");
});

//function to display the data from "listingsInfo" table in terminal.
db.serialize(() => {
    db.each(`SELECT listingID, buildingName, neighbourhoodName, price, ownerName, rentedOrNot, amenities, coworkingSpace
    FROM listingsInfo`, (err, row) => {
        if(err){
            console.error(err.message);
        }
        console.log(row.listingID + "\t" + row.buildingName + "\t" + row.neighbourhoodName + "\t" + row.price + "\t" + row.ownerName + "\t" + row.rentedOrNot);
    })
})

//function to display the data from "Amenities" table in terminal.
// db.serialize(() => {
//     db.each(`SELECT amenityID, equipment
//     FROM Amenities`, (err, row) => {
//         if(err){
//             console.error(err.message);
//         }
//         console.log(row.amenityID + "\t" + row.equipment);
//     })
// })

//function to display the data from "CoworkingSpaces" table in terminal.
// db.serialize(() => {
//     db.each(`SELECT coworkingID, type
//     FROM CoworkingSpaces`, (err, row) => {
//         if(err){
//             console.error(err.message);
//         }
//         console.log(row.coworkingID + "\t" + row.type);
//     })
// })


module.exports = db;