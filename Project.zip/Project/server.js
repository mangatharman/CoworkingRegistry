/* Name: Ruslan Mastov and Harman Mangat (Group 6)
    SODV1201 Project: Develop a CoWorking Registry
*/


var db = require("./listingsDB.js");
var express = require("express");

var app = express();

app.use(express.static(__dirname));
app.use(express.urlencoded({extended: false}));
app.use(express.json());

var server = app.listen(3000, () => {
    console.log("The server is listening on port ", server.address().port);
});

//Declaration of variables
var fields = ["listingID", "buildingName", "neighbourhoodName", "price", "ownerName", "rentedOrNot", "amenities" , "coworkingSpace"];

app.get('/list', function(req, res){ 
    db.all("SELECT " + fields.join(", ") + " FROM listingsInfo", function(err, rows) {
        if (err) {
            res.status(200).json({"error" :err.message});
            return;
          }
        res.json(rows); 
    });                       
});

//Getting the user's input
app.post('/', function(req,res) {

    var data = {
            ID: req.body.listingID,
            buildingName: req.body.buildingName,
            neighbourhoodName: req.body.neighbourhoodName,
            price: req.body.price,
            ownerName: req.body.ownerName,
            coworkingSpace: req.body.coworkingSpace,
            amenities: req.body.amenities,
            rentedOrNot: req.body.rentedOrNot,
    }
    //Creating a variable params and storing the data in it
    var params = [data.buildingName, data.neighbourhoodName, data.price, data.ownerName, data.coworkingSpace, data.amenities, data.rentedOrNot ];

    //Inserting the data in the database
    db.run("INSERT INTO listingsInfo(buildingName, neighbourhoodName, price, ownerName, coworkingSpace, amenities, rentedOrNot) VALUES (?, ?, ?, ?, ?, ?, ?)", params, function(err, data) {
        if(err) throw err;
        console.log("Added Successfully");
    });
    res.redirect('/listings.html')
});

//Deleting the listing
app.post('/delete', function(req, res) {
    var ID = req.body.deleteID;
    
    //Delete query
    db.run("DELETE FROM listingsInfo WHERE listingID = ?", ID, (err, row) => {
      if(err) {
          res.status(400).json({"error":err.message});
          return;
      }
      console.log("Deleted Successfully")
  });
  res.redirect('/listings.html') //Redirecting to the listings page
  });


//Editing the listing
app.post('/edit', function(req,res) {
    //Creating a variable data
    var data = {ID: req.body.ID,
        buildingName: req.body.editBuilding,
        neighbourhoodName: req.body.editNeighbourhood,
        price: req.body.editPrice,
        ownerName: req.body.editOwner,
        coworkingSpace: req.body.editCoworking,
        amenities: req.body.editAmenities,
        rentedOrNot: req.body.editRentedOrNot,
    }

    //Creating a variable params and storing all the data
    var params = [data.buildingName, data.neighbourhoodName, data.price, data.ownerName, data.coworkingSpace, data.amenities, data.rentedOrNot, data.ID];
    console.log(data);
    //Update query
    db.run("UPDATE listingsInfo SET buildingName = ?, neighbourhoodName = ?, price = ?, ownerName = ?,coworkingSpace = ?, amenities = ?, rentedOrNot = ? WHERE listingID = ?", params, function(err, data) {
        if(err) throw err;
        console.log("Edited Successfully");
    });
    res.redirect('/listings.html'); //Redirecting to the listings page
});


