/* Name: Ruslan Mastov and Harman Mangat (Group 6)
    SODV1201 Project: Develop a CoWorking Registry
*/

/* Functions for scrolling up button */

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 150 || document.documentElement.scrollTop > 150) {
        document.getElementById("ScrollBtn").style.display = "block";
    } else {
        document.getElementById("ScrollBtn").style.display = "none";
    }
}
function UpFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}

//Displaying the Listings on the listings page
function getData() {
    $.get("http://localhost:3000/list", (data) => {
        console.log(data);
        var databody = $('#tableInfo').children('databody');
        var table = databody.length ? databody : $('#tableInfo');
        var table_String = "";
        for(var i in data) {
            var listingsInfo = data[i];
            table_String += "<tr>" + "<td>" + listingsInfo.listingID + "</td>" + 
                "<td>" + listingsInfo.buildingName + "</td>" + 
                "<td>" + listingsInfo.neighbourhoodName + "</td>" +
                "<td>" + listingsInfo.ownerName + "</td>" + 
                "<td>" + listingsInfo.amenities + "</td>" + 
                "<td>" + listingsInfo.coworkingSpace + "</td>" +
                "<td>" + listingsInfo.price + "</td>" +
                "<td>" + listingsInfo.rentedOrNot + "</td>" +
                "<td>" + `<button class = "btn-submit">` + `<a href = "createListing.html">` + "Delete" + "</a>" + "</button>" + "</td>" +
                "<td>" + `<button class = "btn-submit">` + `<a href = "editListing.html" target = "_blank">` + "Edit" + "</a>" + "</button>" + "</td>" +
                "</tr>";
        }
        table.append(table_String);
    });
}

//Listings of the filter page
function getRented() {
    //Not Rented
    $.get("http://localhost:3000/list", (data) => {
        console.log(data);
        var databody = $('#notRented').children('databody');
        var databody2 = $('#rented').children('databody2');

        var table1 = databody.length ? databody : $('#notRented');
        var table_String1 = "";
        for(var i in data) {
            var listingsInfo = data[i];
            if (listingsInfo.rentedOrNot == 'Not Rented') {
                table_String1 += "<tr>" + "<td>" + listingsInfo.listingID + "</td>" + 
                    "<td>" + listingsInfo.buildingName + "</td>" + 
                    "<td>" + listingsInfo.neighbourhoodName + "</td>" +
                    "<td>" + listingsInfo.ownerName + "</td>" + 
                    "<td>" + listingsInfo.amenities + "</td>" + 
                    "<td>" + listingsInfo.coworkingSpace + "</td>" +
                    "<td>" + listingsInfo.price + "</td>" +
                    "<td>" + listingsInfo.rentedOrNot + "</td>" +
                    "<td>" + `<button class = "btn-submit">` + `<a href = "createListing.html">` + "Delete" + "</a>" + "</button>" + "</td>" +
                    "<td>" + `<button class = "btn-submit">` + `<a href = "editListing.html" target = "_blank">` + "Edit" + "</a>" + "</button>" + "</td>" +
                    "</tr>";
            }
        }
        table1.append(table_String1);

        //Rented
        var table2 = databody2.length ? databody2 : $('#rented');
        var table_String2 = "";
        for(var i in data) {
            var listingsInfo = data[i];
            if (listingsInfo.rentedOrNot == 'Rented') {
                table_String2 += "<tr>" + "<td>" + listingsInfo.listingID + "</td>" + 
                    "<td>" + listingsInfo.buildingName + "</td>" + 
                    "<td>" + listingsInfo.neighbourhoodName + "</td>" +
                    "<td>" + listingsInfo.ownerName + "</td>" + 
                    "<td>" + listingsInfo.amenities + "</td>" + 
                    "<td>" + listingsInfo.coworkingSpace + "</td>" +
                    "<td>" + listingsInfo.price + "</td>" +
                    "<td>" + listingsInfo.rentedOrNot + "</td>" +
                    "<td>" + `<button class = "btn-submit">` + `<a href = "createListing.html">` + "Delete" + "</a>" + "</button>" + "</td>" +
                    "<td>" + `<button class = "btn-submit">` + `<a href = "editListing.html" target = "_blank">` + "Edit" + "</a>" + "</button>" + "</td>" +
                    "</tr>";
            }
        }
        table2.append(table_String2);
    });
}


//Phase 1 JavaScript


// // The Listing Array

// // Index = {0 = Name of the Building, 1 = Name of Neighbourhood, 2 = Price, 3 = Name of Owner, 4 = Rented/Not-rented}
// var listing = [
//     ["Bowness Building", "Bowness", "$500 /mo", "David Black", "Not Rented"],
//     ["Effectiv Innovation Center", "1 Street SE", "$450 /mo", "Effectiv Inc", "Rented"],
//     ["Workhaus Core", "4 Street SW", "$350 /mo", "Ethan Pelensky", "Not Rented"],
//     ["TradeSpace", "8 Street SE", "$550 /mo", "TradeSpace Inc", "Not Rented"],
//     ["ReSourceYYC", "9 Avenue SE", "$250 /mo", "ReSourceYYC Inc", "Rented"]
    
// ];

// //Storing the Coworking Space in an Array
// var cSpace = [
//     ["Desk in Shared Space", "Desk in Private Room"],
//     ["Desk in Private Room"],
//     ["Desk in Shared Space", "Desk in Private Room"],
//     ["Desk in Shared Space", "Desk in Private Room", "Meeting Space"],
//     ["Desk in Shared Space"]
// ];

// //Storing the amenities in an array
// var amenities = [
//     ["Wi-fi", "Printer", "Fax", "Showers", "Bike Locker", "Meeting Room", "Projector"],
//     ["Printer", "Fax", "Showers"],
//     ["Wi-fi", "Printer", "Fax", "Meeting Room", "Projector"],
//     ["Wi-fi", "Printer", "Fax", "Showers", "Bike Locker", "Projector"],
//     ["Wi-fi", "Printer", "Fax", "Projector"]
// ];

// //Storing all the images in an array
// var images = new Array();

//     for (var i = 0; i <listing.length; i++) {
//         images[i] = "img/Coworking-Space" + i + ".jpg";
//     }



// function viewListing() {
// //Loops for displaying all the information of the arrays
//     //Displaying the elements from the listing array
//     for (var i = 0;  i < listing.length; i++) { 
//         document.getElementById("listing1").innerHTML += "<b>Name of the Builidng: </b>" + listing[i][0] + "</br>";
//         document.getElementById("listing1").innerHTML += "<b>Name of the Neighborhood: </b>" + listing[i][1] + "</br>";
//         document.getElementById("listing1").innerHTML += "<b>Price: </b>" + listing[i][2] + "</br>";
//         document.getElementById("listing1").innerHTML += "<b>Name of the Owner: </b>" + listing[i][3] + "</br>";
//         document.getElementById("listing1").innerHTML += "<b>Rented/Not-Rented: </b>" + listing[i][4] + "</br>";

//         //displaying the elements from the amenities array
//         document.getElementById("listing1").innerHTML += "<b>Amenities: </b>";
//         for (var j = 0; j < amenities[i].length; j++) {
//             document.getElementById("listing1").innerHTML += amenities[i][j];
//             if (j != amenities[i].length - 1) //Adding a comma
//                 document.getElementById("listing1").innerHTML += ", ";
//         }
//         document.getElementById("listing1").innerHTML += "</br>";
        
//         //displaying the elements from the coWorking space array
//         document.getElementById("listing1").innerHTML += "<b>Coworking Space: </b>";
//         for (var j = 0; j < cSpace[i].length; j++) {
//             document.getElementById("listing1").innerHTML += cSpace[i][j];
//             if (j != cSpace[i].length - 1) //Adding a comma 
//                 document.getElementById("listing1").innerHTML += ", ";
//         }
//         document.getElementById("listing1").innerHTML += "</br></br>";

//         //Displaying all the images that we had stored in the array
//         var img = document.createElement('img');
//         img.src = images[i];
//         document.getElementById("listing1").appendChild(img);
//         img.setAttribute("id", "image");
        
//         //Line break between listings
//         document.getElementById("listing1").innerHTML += "</br></br></br></br>";
       
//     }
// }


    
    